package com.example.objdetection;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.task.vision.detector.Detection;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CAPTURE_IMAGE = 1;
    private static final int REQUEST_SELECT_IMAGE = 2;
    private static final int REQUEST_SELECT_VIDEO = 3;
    private static final int STORAGE_PERMISSION_REQUEST_CODE = 101;

    private ImageView imageView;
    private VideoView videoView;
    private ObjectDetectionHelper objectDetectionHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize object detection helper with the model
        objectDetectionHelper = new ObjectDetectionHelper(this, "model.tflite");

        // Initialize UI elements (buttons, imageView, videoView)
        Button btnCaptureImage = findViewById(R.id.btnCaptureImage);
        Button btnDetectWithImage = findViewById(R.id.btnDetectWithImage);
        Button btnUploadVideo = findViewById(R.id.btnUploadVideo);
        imageView = findViewById(R.id.imageView);
        videoView = findViewById(R.id.videoView);

        // Request storage permission
        requestStoragePermission();

        // Button click listeners
        btnCaptureImage.setOnClickListener(v -> openCamera());
        btnDetectWithImage.setOnClickListener(v -> {
            if (isStoragePermissionGranted()) {
                openImagePicker();
            } else {
                Toast.makeText(this, "Storage permission is required to pick an image", Toast.LENGTH_SHORT).show();
            }
        });
        btnUploadVideo.setOnClickListener(v -> {
            if (isStoragePermissionGranted()) {
                openVideoPicker();
            } else {
                Toast.makeText(this, "Storage permission is required to pick a video", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void openCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, REQUEST_CAPTURE_IMAGE);
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(intent, REQUEST_SELECT_IMAGE);
    }

    private void openVideoPicker() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        intent.setType("video/*");
        startActivityForResult(intent, REQUEST_SELECT_VIDEO);
    }

    private boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        } else {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!isStoragePermissionGranted()) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_MEDIA_IMAGES}, STORAGE_PERMISSION_REQUEST_CODE);
            }
        } else {
            if (!isStoragePermissionGranted()) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST_CODE);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == REQUEST_CAPTURE_IMAGE) {
                Bundle extras = data.getExtras();
                if (extras != null) {
                    Bitmap bitmap = (Bitmap) extras.get("data");
                    imageView.setImageBitmap(bitmap);
                    videoView.setVisibility(View.GONE);
                    imageView.setVisibility(View.VISIBLE);

                    detectObjects(bitmap);
                }
            } else if (requestCode == REQUEST_SELECT_IMAGE) {
                Uri selectedImageUri = data.getData();
                if (selectedImageUri != null) {
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                        imageView.setImageURI(selectedImageUri);
                        videoView.setVisibility(View.GONE);
                        imageView.setVisibility(View.VISIBLE);

                        detectObjects(bitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            Toast.makeText(this, "No media selected", Toast.LENGTH_SHORT).show();
        }
    }

    private void detectObjects(Bitmap bitmap) {
        if (objectDetectionHelper == null) {
            Toast.makeText(this, "TensorFlow model is not loaded", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convert bitmap to TensorImage for TensorFlow Lite processing
        TensorImage tensorImage = TensorImage.fromBitmap(bitmap);
        List<Detection> results = objectDetectionHelper.detectObjects(tensorImage);

        // Log detection results
        for (Detection detection : results) {
            // Get the categories for each detection
            List<Detection.Category> categories = detection.getCategories();
            for (Detection.Category category : categories) {
                // Get label and score
                String label = category.getLabel();
                float score = category.getScore();

                // Log the results
                Log.d("ObjectDetection", "Detected: " + label + " - Confidence: " + score);
            }
        }
        Toast.makeText(this, "Object detection completed. Check logs.", Toast.LENGTH_SHORT).show();
    }
}
