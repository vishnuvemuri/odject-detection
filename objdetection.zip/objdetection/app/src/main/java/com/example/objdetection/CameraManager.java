package com.example.objdetection;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.camera.core.Camera;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.core.CameraSelector;
import androidx.lifecycle.LifecycleOwner;
import androidx.camera.view.PreviewView;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CameraManager {
    private static final String TAG = "CameraManager";

    private Context context;
    private LifecycleOwner lifecycleOwner;
    private PreviewView previewView;
    private ExecutorService cameraExecutor;
    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private ImageCapture imageCapture;

    public CameraManager(Context context, LifecycleOwner lifecycleOwner, PreviewView previewView) {
        this.context = context;
        this.lifecycleOwner = lifecycleOwner;
        this.previewView = previewView;
        cameraExecutor = Executors.newSingleThreadExecutor();
        initializeCamera();
    }

    private void initializeCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(context);
        cameraProviderFuture.addListener(() -> {
            try {
                // CameraProvider
                cameraProvider = cameraProviderFuture.get();

                // Preview Use Case
                Preview preview = new Preview.Builder()
                        .build();

                // Ensure that getSurfaceProvider() is called on the main thread
                new Handler(Looper.getMainLooper()).post(() -> {
                    preview.setSurfaceProvider(previewView.getSurfaceProvider());
                });

                // ImageCapture Use Case
                imageCapture = new ImageCapture.Builder()
                        .build();

                // CameraSelector (Optional: specify front or back camera)
                CameraSelector cameraSelector = new CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build();

                // Ensure binding to lifecycle is called on the main thread
                new Handler(Looper.getMainLooper()).post(() -> {
                    try {
                        // Bind Preview and ImageCapture to Lifecycle
                        camera = cameraProvider.bindToLifecycle(
                                lifecycleOwner,   // LifecycleOwner is needed to bind the camera
                                cameraSelector,    // Optional: specify which camera to use
                                preview,           // Preview use case
                                imageCapture       // ImageCapture use case
                        );
                    } catch (Exception e) {
                        Log.e(TAG, "Error binding camera to lifecycle: " + e.getMessage());
                    }
                });

            } catch (ExecutionException | InterruptedException e) {
                Log.e(TAG, "Error initializing camera: " + e.getMessage());
            }
        }, cameraExecutor);
    }

    public void captureImage(Context context) {
        if (imageCapture == null) {
            Log.e(TAG, "ImageCapture is not initialized");
            return;
        }

        // Capture Image logic (you may need to pass a File or OutputOptions here)
    }

    public void startCamera() {
        // Ensuring the camera is started on the main thread
        new Handler(Looper.getMainLooper()).post(() -> {
            // Camera start logic (if needed)
            Log.d(TAG, "Camera is starting...");
        });
    }

    public void releaseCamera() {
        // Release camera resources when no longer needed
        if (camera != null) {
            cameraProvider.unbindAll();
            camera = null;
            Log.d(TAG, "Camera resources released");
        }
    }
}
