package com.example.objdetection;

import android.graphics.Bitmap;

public interface CameraCaptureCallback {
    void onImageCaptured(Bitmap bitmap);
    void onError(String error);
}
