package com.example.objdetection;

import android.content.Context;
import org.tensorflow.lite.Interpreter;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;
import org.tensorflow.lite.support.image.TensorImage;

import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.io.FileInputStream;

public class TFLiteModel {

    private Interpreter interpreter;

    public TFLiteModel(Context context) {
        try {
            MappedByteBuffer model = loadModelFile(context);
            interpreter = new Interpreter(model);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private MappedByteBuffer loadModelFile(Context context) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(context.getAssets().openFd("model.tflite").getFileDescriptor());
        FileChannel fileChannel = fileInputStream.getChannel();
        long startOffset = fileInputStream.getChannel().position();
        long declaredLength = fileInputStream.getChannel().size();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    public TensorBuffer runModel(TensorImage inputImage) {
        // Assuming model outputs are in the TensorBuffer format
        TensorBuffer outputBuffer = TensorBuffer.createFixedSize(new int[]{1, 100}, org.tensorflow.lite.DataType.FLOAT32);
        interpreter.run(inputImage.getBuffer(), outputBuffer.getBuffer());
        return outputBuffer;
    }
}
