package com.example.objdetection;

import android.content.Context;

import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.task.vision.detector.Detection;
import org.tensorflow.lite.task.vision.detector.ObjectDetector;
import org.tensorflow.lite.task.vision.detector.ObjectDetector.ObjectDetectorOptions;

import java.util.List;

public class ObjectDetectionHelper {
    private final ObjectDetector objectDetector;

    public ObjectDetectionHelper(Context context, String modelPath) {
        try {
            // Initialize ObjectDetector with options
            ObjectDetectorOptions options =
                    ObjectDetectorOptions.builder()
                            .setMaxResults(5) // Maximum detections
                            .setScoreThreshold(0.5f) // Confidence threshold
                            .build();

            objectDetector = ObjectDetector.createFromFileAndOptions(context, modelPath, options);

        } catch (Exception e) {
            throw new RuntimeException("Error initializing ObjectDetector: " + e.getMessage());
        }
    }

    public List<Detection> detectObjects(TensorImage bitmap) {
        TensorImage tensorImage = TensorImage.fromBitmap(bitmap.getBitmap());
        return objectDetector.detect(tensorImage);
    }
}
