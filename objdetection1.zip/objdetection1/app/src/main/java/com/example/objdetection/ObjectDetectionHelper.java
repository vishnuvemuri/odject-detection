package com.example.objdetection;

import org.tensorflow.lite.support.image.TensorImage;
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer;

public class ObjectDetectionHelper {

    private TFLiteModel tfliteModel;

    public ObjectDetectionHelper(TFLiteModel tfliteModel) {
        this.tfliteModel = tfliteModel;
    }

    public String detectObject(TensorImage image) {
        // Run the TensorFlow Lite model
        TensorBuffer outputBuffer = tfliteModel.runModel(image);

        // Process the output and extract the detected object
        // Assuming the model returns a float array for object labels
        float[] outputArray = outputBuffer.getFloatArray();
        // For now, return the first label (this is just a placeholder; modify it based on your model)
        return "Detected Object: " + outputArray[0];
    }
}
