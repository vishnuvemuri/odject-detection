package com.example.objdetection;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.util.Log;
import android.view.Surface;

import androidx.camera.core.Camera;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.core.CameraSelector;
import androidx.lifecycle.LifecycleOwner;
import androidx.camera.view.PreviewView;
import androidx.camera.core.ImageCaptureException;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CameraManager {
    private static final String TAG = "CameraManager";

    private Context context;
    private LifecycleOwner lifecycleOwner;
    private PreviewView previewView;
    private ExecutorService cameraExecutor;
    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private ImageCapture imageCapture;

    public CameraManager(Context context, LifecycleOwner lifecycleOwner, PreviewView previewView) {
        this.context = context;
        this.lifecycleOwner = lifecycleOwner;
        this.previewView = previewView;
        cameraExecutor = Executors.newSingleThreadExecutor();
        initializeCamera();
    }

    private void initializeCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(context);
        cameraProviderFuture.addListener(() -> {
            try {
                // CameraProvider
                cameraProvider = cameraProviderFuture.get();

                // Preview Use Case
                Preview preview = new Preview.Builder()
                        .build();

                preview.setSurfaceProvider(previewView.getSurfaceProvider());

                // ImageCapture Use Case
                imageCapture = new ImageCapture.Builder()
                        .build();

                // CameraSelector (Optional: specify front or back camera)
                CameraSelector cameraSelector = new CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build();

                // Bind Preview and ImageCapture to Lifecycle
                camera = cameraProvider.bindToLifecycle(
                        lifecycleOwner,   // LifecycleOwner is needed to bind the camera
                        cameraSelector,    // Optional: specify which camera to use
                        preview,           // Preview use case
                        imageCapture       // ImageCapture use case
                );
            } catch (ExecutionException | InterruptedException e) {
                Log.e(TAG, "Error initializing camera: " + e.getMessage());
            }
        }, cameraExecutor);
    }

    public void captureImage() {
        if (imageCapture == null) {
            Log.e(TAG, "ImageCapture is not initialized");
            return;
        }

        // Capture Image logic (you may need to pass a File or OutputOptions here)
    }

    public void startCamera() {
        
    }
}
