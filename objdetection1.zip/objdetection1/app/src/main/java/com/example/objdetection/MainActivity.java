package com.example.objdetection;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.view.PreviewView;
import androidx.lifecycle.LifecycleOwner;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private CameraManager cameraManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get the PreviewView from the layout
        PreviewView previewView = findViewById(R.id.previewView);

        // Initialize the CameraManager with MainActivity as LifecycleOwner
        cameraManager = new CameraManager(this, this, previewView);

        // Start the camera
        startCamera();
    }

    // Start camera function to initialize the camera
    private void startCamera() {
        if (cameraManager != null) {
            // Call the start camera function from CameraManager
            cameraManager.startCamera();
        } else {
            Log.e(TAG, "CameraManager is not initialized");
        }
    }
}
